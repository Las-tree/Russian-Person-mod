# Russian_Person
Mod for C:DDA that add a new character to the game.
